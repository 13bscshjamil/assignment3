<?php
$PwdErr = $error = $emailErr = "";
   include("config.php");   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
	   
	if (empty($_POST["UEMAIL"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["UEMAIL"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format."; 
    }
  }
if (empty($_POST["PWD"])) {
    $PwdErr = "Password is required.";
  }
	elseif (!empty($_POST["UEMAIL"]) and !empty($_POST["PWD"]) and filter_var($email, FILTER_VALIDATE_EMAIL)){
	$myemail = mysqli_real_escape_string($conn,$_POST['UEMAIL']);
    $mypassword = mysqli_real_escape_string($conn,$_POST['PWD']); 
      
      $sql = "INSERT INTO userdata (email, password)
			VALUES ('$myemail', '$mypassword')";
	if (mysqli_query($conn, $sql)) {
		header("location: SignUpSuccess.php");
		} 
	else {
    $error = "You did not enter a valid email address or there already exists an account with the same email address.";
	 // echo $error;
	}
	}
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<html>
   
   <head>
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
	.error {color: #FF0000;}
      </style>
      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b> SignUp </b></div>
				
            <div style = "margin:30px">
               
               <form action = "" method = "post"> 
				 
				  <span class="error"> <?php echo $error;?>  <br> <br> </span> 
                  <label> Please enter your email address. <br> </label> <input type = "text" name = "UEMAIL" class = "box"/><br/>
				  <span class="error"> <?php echo $emailErr;?> <br> <br> </span>
                  <label> Please set a password. </label> <input type = "password" name = "PWD" class = "box" /><br/>
				  <span class="error"> <?php echo $PwdErr;?>  <br> <br> </span>
                  <input type = "submit" value = " SignUp "/><br />
               </form>
            
					
            </div>
				
         </div>
			
      </div>

   </body>
</html>