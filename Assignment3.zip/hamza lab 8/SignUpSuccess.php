<?php
?>
<html>
   <head>
      <title> Welcome </title>
   </head>
   
   <body>
      <h3> You have successfully created an account. </h3>
      <h3> Please use that email and password to <a href = "login.php"> Sign In </a> to your account. </h3>
   </body>
   
</html>