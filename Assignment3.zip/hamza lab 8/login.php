<?php

$PwdErr = $error = $emailErr = "";
   include("config.php");   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
	
   if (empty($_POST["UEMAIL"])) {
    $emailErr = "Email is required.";
  } else {
    $email = test_input($_POST["UEMAIL"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format."; 
    }
  }
  if (empty($_POST["PWD"])) {
    $PwdErr = "Password is required";
  }
   
   elseif (!empty($_POST["UEMAIL"]) and !empty($_POST["PWD"]) and filter_var($email, FILTER_VALIDATE_EMAIL)){
   
   $myemail = mysqli_real_escape_string($conn,$_POST['UEMAIL']);
   $mypassword = mysqli_real_escape_string($conn,$_POST['PWD']);
      
      $sql = "SELECT email FROM userdata WHERE email = '$myemail' and password = '$mypassword'";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
     
	  $count = mysqli_num_rows($result);
      if($count == 1) {
      header("location: survey.php");
      } 
	  elseif ($count != 1)  {
      $error = "Your email or Password is incorrect! Please try again.";
	 // echo $error; 
	  } 
   }
	  }
	   
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}	   
?>
<html>
   
   <head>
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
	.error {color: #FF0000;}
      </style>
      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>
				
            <div style = "margin:30px">
               <h4> IF you do not have an account please <a href = "signup.php"> Sign up </a></h4>  <hr>
			   <h4> IF you already have an account then sign in. </h4>
               <form action = "" method = "post"> 
				 
				  <span class="error"> <?php echo $error;?>  <br> <br> </span>
                  <label> Email  : <br> </label><input type = "text" name = "UEMAIL" class = "box"/><br />
				  <span class="error"> <?php echo $emailErr;?> <br> <br> </span>
                  <label> Password  :</label><input type = "password" name = "PWD" class = "box" /> <br />
				  <span class="error"> <?php echo $PwdErr;?>  <br> <br> </span>
                  <input type = "submit" value = " Submit "/><br>
               </form>
					
            </div>
				
         </div>
			
      </div>

   </body>
</html>